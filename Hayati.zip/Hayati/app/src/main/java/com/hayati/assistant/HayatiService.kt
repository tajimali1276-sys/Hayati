package com.hayati.assistant

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class HayatiService : Service(), RecognitionListener {

    private lateinit var sr: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private val h = Handler(Looper.getMainLooper())
    private var awake = false

    // Hindi script mein aane wale alag-alag spelling bhi pakad lo
    private val wake = listOf("hayati", "hayaati", "हयाती", "हयात", "हयाति", "हायती")

    // "hi-IN" = Hindi script, "en-IN" = Roman/Hinglish. Contact names ke hisaab se badlo.
    private val LANG = "en-IN"

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("hayati", "Hayati", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "hayati")
            .setContentTitle("Hayati sun rahi hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(this)
        listen()
    }

    private fun speak(t: String) { tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "h") }

    private fun listen() = h.post {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANG)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { sr.startListening(i) } catch (e: Exception) { h.postDelayed({ listen() }, 1000) }
    }

    override fun onResults(r: Bundle?) {
        val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()?.lowercase() ?: ""
        val hit = wake.firstOrNull { text.contains(it) }
        when {
            hit != null -> {
                val cmd = text.replace(hit, "").trim()
                if (cmd.isEmpty()) { awake = true; speak("Ji, boliye") }
                else { awake = false; Commands.handle(this, cmd, ::speak) }
            }
            awake -> { awake = false; Commands.handle(this, text, ::speak) }
        }
        h.postDelayed({ listen() }, 400)
    }

    override fun onError(e: Int) { h.postDelayed({ listen() }, 800) }

    override fun onDestroy() {
        sr.destroy(); tts.shutdown(); super.onDestroy()
    }

    override fun onBind(i: Intent?) = null
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(t: Int, p: Bundle?) {}
}
