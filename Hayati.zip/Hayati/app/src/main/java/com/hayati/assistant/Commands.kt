package com.hayati.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telephony.SmsManager

object Commands {

    private val h = Handler(Looper.getMainLooper())

    private val pkg = mapOf(
        "instagram" to "com.instagram.android",
        "insta" to "com.instagram.android",
        "इंस्टाग्राम" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "फेसबुक" to "com.facebook.katana",
        "whatsapp" to "com.whatsapp",
        "व्हाट्सएप" to "com.whatsapp",
        "youtube" to "com.google.android.youtube",
        "यूट्यूब" to "com.google.android.youtube"
    )

    fun handle(ctx: Context, t: String, say: (String) -> Unit) {
        when {
            // 1) Instagram comment reply: "instagram reply <text>"
            t.contains("reply") && (t.contains("insta") || t.contains("इंस्टा")) -> {
                val msg = t.replace(Regex("(instagram|insta|reply|इंस्टाग्राम|comment|कमेंट)"), " ").trim()
                say("Instagram par reply likh rahi hun")
                instagramReply(ctx, msg)
            }

            // 2) Call
            Regex("call|कॉल|फोन|phone").containsMatchIn(t) -> {
                val name = t.replace(Regex("\\b(ko|call|karo|kar|do|phone|lagao|laga|कॉल|को|करो|लगाओ|फोन)\\b"), " ").trim()
                val num = Regex("\\+?\\d[\\d ]{6,}").find(name)?.value?.replace(" ", "")
                    ?: findNumber(ctx, name)
                if (num == null) { say("$name contact nahi mila"); return }
                say("$name ko call laga rahi hun")
                ctx.startActivity(
                    Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }

            // 3) WhatsApp: "whatsapp Ammi main aa raha hun"
            t.contains("whatsapp") || t.contains("व्हाट्सएप") -> {
                val m = Regex("(?:whatsapp|व्हाट्सएप)\\s+(\\S+)\\s*(.*)").find(t)
                if (m == null) { open(ctx, "com.whatsapp", say, "WhatsApp"); return }
                val (name, msg) = m.destructured
                val num = findNumber(ctx, name)?.filter { it.isDigit() }
                if (num == null) { say("$name contact nahi mila"); return }
                say("$name ko WhatsApp bhej rahi hun")
                val i = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/$num?text=" + Uri.encode(msg))
                ).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                // Chat khulne ke baad "Send" button apne aap dabao
                h.postDelayed({ HayatiAccessibility.inst?.clickText("Send") }, 3500)
            }

            // 4) SMS: "sms Bhai kal milte hain"
            t.startsWith("sms") || t.contains("एसएमएस") -> {
                val m = Regex("(?:sms|एसएमएस)\\s+(\\S+)\\s+(.*)").find(t)
                if (m == null) { say("Aise bolo: sms naam message"); return }
                val (name, msg) = m.destructured
                val num = findNumber(ctx, name)
                if (num == null) { say("$name contact nahi mila"); return }
                @Suppress("DEPRECATION")
                val sms = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
                sms.sendMultipartTextMessage(num, null, sms.divideMessage(msg), null, null)
                say("$name ko SMS bhej diya")
            }

            // 5) Apps kholna
            else -> {
                val key = pkg.keys.firstOrNull { t.contains(it) }
                if (key != null) open(ctx, pkg[key]!!, say, key)
                else if (t.contains("back") || t.contains("peeche") || t.contains("वापस")) {
                    HayatiAccessibility.inst?.back()
                } else say("Ye command abhi nahi aata")
            }
        }
    }

    private fun open(ctx: Context, p: String, say: (String) -> Unit, label: String) {
        val i = ctx.packageManager.getLaunchIntentForPackage(p)
        if (i == null) { say("$label install nahi hai"); return }
        say("$label khol rahi hun")
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // Instagram ke andar comment box dhoondh kar likhna aur Post dabana.
    // NOTE: Instagram ka UI badalta rehta hai; text "Add a comment" / "Post" apne phone ki language ke hisaab se badlo.
    private fun instagramReply(ctx: Context, msg: String) {
        val a = HayatiAccessibility.inst ?: return
        h.postDelayed({
            a.clickText("Reply")
            h.postDelayed({
                a.clickText("Add a comment")
                h.postDelayed({
                    a.typeText(msg)
                    h.postDelayed({ a.clickText("Post") }, 800)
                }, 800)
            }, 800)
        }, 500)
    }

    private fun findNumber(ctx: Context, name: String): String? {
        if (name.isBlank()) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }
}
